//
//  MasterViewController.swift
//  FinalWebBrowserApp
//
//  Created by Aidana Ketebay on 21.02.18.
//  Copyright © 2018 Aidana Ketebay. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController {
    
    var BrowserList: [Browser] = [
        Browser.init("Google", "https://google.kz"),
        Browser.init("Instagram", "https://instagram.com"),
        Browser.init("Vk.com", "https://vk.com"),
        Browser.init("Apple", "https://apple.com"),
    ]
    
    var favouriteOpened: Bool = false
    
    var FavouriteBrowser: [Browser] = []
    
    @IBAction func typePressed(_ sender: UISegmentedControl) {
        if favouriteOpened{
            favouriteOpened = false
        }
        else{
            favouriteOpened = true
        }
        tableView.reloadData()
    }
    
    
    @IBOutlet weak var ttableView: UITableView!
    @IBAction func addPressed(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "BrowserApplication", message: "Fill the Blanks", preferredStyle: .alert)
        let actionOk = UIAlertAction(title: "OK", style: .default){ (action) in
            if let title = alert.textFields?[0].text, let link = alert.textFields?[1].text{
                if(title != "" && link != ""){
                    self.BrowserList.append(Browser.init(title, link))
                    self.tableView.reloadData()
                }
                else{}
            }
            else{}
        }
        
        alert.addTextField{ (titleFilled) in
            titleFilled.placeholder = "Title"
        }
        alert.addTextField{ (linkFilled) in
            linkFilled.placeholder = "Link"
        }
        alert.addAction(actionOk)
        self.present(alert, animated: true){
            print("Done")
        }
    }
    
    /*func save(a browser: Browser) {
        BrowserList.append(browser)
        ttableView.reloadData()
        tableView.reloadData()
    }*/
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    /*override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }*/

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if(favouriteOpened){
            
            return FavouriteBrowser.count
        }
        else{
            return BrowserList.count
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(favouriteOpened){
            let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)
            
            // Configure the cell...
            //cell.textLabel?.text = BrowserList[indexPath.row].Url
            let browsers = FavouriteBrowser[indexPath.row]
            cell.textLabel?.text = browsers.Title
            
            return cell
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)

            // Configure the cell...
           //cell.textLabel?.text = BrowserList[indexPath.row].Url
            let browsers = BrowserList[indexPath.row]
            cell.textLabel?.text = browsers.Title

            return cell
        }
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */


    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
    if segue.identifier == "mySegue"{
        if let contentViewController = segue.destination as? DetailViewController{
            
            contentViewController.index = (tableView.indexPathForSelectedRow?.row)!
                contentViewController.name = BrowserList[(tableView.indexPathForSelectedRow?.row)!].Title
            contentViewController.website = BrowserList[(tableView.indexPathForSelectedRow?.row)!].Url
                contentViewController.previousViewController = self
            
                
            }
        }
        
        
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    func checker(_ index: Int){
        
        tableView.reloadData()
    }
    
    

}
