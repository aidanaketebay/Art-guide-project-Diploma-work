//
//  DetailViewController.swift
//  FinalWebBrowserApp
//
//  Created by Aidana Ketebay on 21.02.18.
//  Copyright © 2018 Aidana Ketebay. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    //var selected: BrowserSelected?
    var website : String?
    var name: String?
    var previousViewController : MasterViewController?
    var index: Int?
    @IBOutlet weak var webView: UIWebView!
    var save: Add?
    var isFavourite: Bool?
    
    
    
    @IBOutlet weak var loading: UIActivityIndicatorView!
    @IBOutlet weak var navigation: UINavigationBar!
    
    @IBOutlet weak var curBrowser: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        loading.startAnimating()
        if let nonOptionalWebsite = website{
            if !(previousViewController?.favouriteOpened)!{
                self.curBrowser.text = previousViewController?.BrowserList[index!].Title
                let site_url = URL(string: nonOptionalWebsite)
                webView.loadRequest(URLRequest(url: site_url!))
                loading.stopAnimating()
            }
            else{
                self.curBrowser.text = previousViewController?.FavouriteBrowser[index!].Title
                let site_url = URL(string: nonOptionalWebsite)
                webView.loadRequest(URLRequest(url: site_url!))
                loading.stopAnimating()
            }
            if (previousViewController?.favouriteOpened)!{
                self.navigation.backgroundColor = UIColor.yellow
            }
            
           // self.previousViewController?.title = previousViewController?.BrowserList[index!].Title
            //self.curBrowser.text =  previousViewController?.BrowserList[index!].Title
            
            
        }
        
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tap))
        tapGesture.numberOfTapsRequired = 3
        self.webView.addGestureRecognizer(tapGesture)
    }
    @objc func tap() {
        if(previousViewController?.FavouriteBrowser.contains(where: {$0.Url == website}))!{
            previousViewController?.FavouriteBrowser.remove(at: index!)
            self.navigation.backgroundColor = UIColor.white
        }
        else{
            self.navigation.backgroundColor = UIColor.yellow
            isFavourite = true
            previousViewController?.FavouriteBrowser.append(Browser.init(name!,website!))
            print(previousViewController?.BrowserList[index!].Title!)
            print(previousViewController?.BrowserList[index!].Url!)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        //previousViewController?.checker(index!)
        //loading.stopAnimating()
        //navigationController?.popViewController(animated: true)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
