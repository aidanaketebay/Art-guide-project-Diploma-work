//
//  Browser.swift
//  FinalWebBrowserApp
//
//  Created by Aidana Ketebay on 21.02.18.
//  Copyright © 2018 Aidana Ketebay. All rights reserved.
//

import Foundation
import UIKit

class Browser{
    private var browser_title: String?
    private var browser_url: String?
    init(_ browser_title: String, _ browser_url : String){
        self.browser_title = browser_title
        self.browser_url = browser_url
    }
    var Url : String?{
        get{return browser_url}
        
    }
    var Title: String?{
        get{return browser_title}
    }
}
