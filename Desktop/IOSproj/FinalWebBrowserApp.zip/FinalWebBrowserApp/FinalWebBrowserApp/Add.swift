//
//  Add.swift
//  FinalWebBrowserApp
//
//  Created by Aidana Ketebay on 23.02.18.
//  Copyright © 2018 Aidana Ketebay. All rights reserved.
//

import Foundation
protocol Add {
    func saveFav(a browser: Browser)
}
